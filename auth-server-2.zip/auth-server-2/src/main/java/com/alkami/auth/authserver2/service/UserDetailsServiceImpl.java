package com.alkami.auth.authserver2.service;

import com.alkami.auth.authserver2.domain.UserAccount;
import com.alkami.auth.authserver2.domain.UserDetailsImpl;
import com.alkami.auth.authserver2.repository.UserAccountRepository;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Objects;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {

    private final UserAccountRepository userAccountRepository;

    public UserDetailsServiceImpl(UserAccountRepository userAccountRepository) {
        this.userAccountRepository = userAccountRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        UserAccount userAccount = userAccountRepository.findByUsername(username);
        if (Objects.isNull(userAccount)) {
            throw new UsernameNotFoundException("User not found.");
        }

        return new UserDetailsImpl.Builder()
                .withUsername(userAccount.getUsername())
                .withPassword(userAccount.getPassword())
                .build();
    }

}
