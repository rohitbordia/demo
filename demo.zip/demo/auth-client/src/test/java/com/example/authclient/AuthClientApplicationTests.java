package com.example.authclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthClientApplicationTests {

    @Test
    void contextLoads() {
    }

}
