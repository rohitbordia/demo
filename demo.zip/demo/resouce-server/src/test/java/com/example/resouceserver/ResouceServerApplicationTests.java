package com.example.resouceserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResouceServerApplicationTests {

    @Test
    void contextLoads() {
    }

}
