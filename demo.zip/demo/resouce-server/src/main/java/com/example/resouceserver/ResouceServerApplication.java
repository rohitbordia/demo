package com.example.resouceserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.Map;

@SpringBootApplication
public class ResouceServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(ResouceServerApplication.class, args);
    }

}


@Controller
@ResponseBody

class GreetingsController {

    @GetMapping("/")
    Map<String,String> greet(@AuthenticationPrincipal Jwt jwt){
        return Map.of("message", "hello");
    }

}